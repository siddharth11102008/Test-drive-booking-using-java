
import java.util.Scanner;
import service.BookingService;
import service.CarService;
import service.FeedbackService;
import service.ReportService;

public class Main {

    static Scanner sc = new Scanner(System.in);

    public static void main(String[] args) {

        CarService carService = new CarService();
        BookingService bookingService = new BookingService();
        FeedbackService feedbackService = new FeedbackService();
        ReportService reportService = new ReportService();

        int choice;

        do {
            System.out.println("\n===== CAR TEST DRIVE SYSTEM =====");
            System.out.println("1. Car Management");
            System.out.println("2. Book Test Drive");
            System.out.println("3. View Booking History");
            System.out.println("4. Send Feedback");
            System.out.println("5. Generate Report");
            System.out.println("0. Exit");
            System.out.print("Enter choice: ");

            choice = sc.nextInt();

                switch (choice) {

                case 1 -> carMenu(carService);

                case 2 -> bookingService.bookTestDrive();

                case 3 -> bookingService.viewBookings();

                case 4 -> feedbackService.addFeedback();

                case 5 -> reportService.generateReport();

                case 0 -> System.out.println("Exiting...");

                default -> System.out.println("Invalid choice!");
            }

        } while (choice != 0);
    }

    // ================= CAR MENU =================
    public static void carMenu(CarService carService) {

        int ch;

        do {
            System.out.println("\n--- CAR MANAGEMENT ---");
            System.out.println("1. Add Car");
            System.out.println("2. View Cars");
            System.out.println("3. Update Car");
            System.out.println("4. Delete Car");
            System.out.println("0. Back");
            System.out.print("Enter choice: ");

            ch = sc.nextInt();

            switch (ch) {
                case 1 -> carService.addCar();
                case 2 -> carService.viewCars();
                case 3 -> carService.updateCar();
                case 4 -> carService.deleteCar();
                case 0 -> {
                }
                default -> System.out.println("Invalid choice!");
            }

        } while (ch != 0);
    }
}
