package model;

public class Booking {

    private int bookingId;
    private String customerName;
    private int carId;
    private String slot;
    private String date;

    public Booking(int bookingId, String customerName, int carId, String slot, String date) {
        this.bookingId = bookingId;
        this.customerName = customerName;
        this.carId = carId;
        this.slot = slot;
        this.date = date;
    }

    public String toFileString() {
        return bookingId + "," + customerName + "," + carId + "," + slot + "," + date;
    }

    public static Booking fromFileString(String line) {
        String[] data = line.split(",");
        return new Booking(
                Integer.parseInt(data[0]),
                data[1],
                Integer.parseInt(data[2]),
                data[3],
                data[4]
        );
    }

    public int getBookingId() { return bookingId; }

    public String getCustomerName() { return customerName; }

    public int getCarId() { return carId; }

    public String getSlot() { return slot; }

    public String getDate() { return date; }

    @Override
    public String toString() {
        return bookingId + " | " + customerName + " | Car ID: " + carId +
                " | " + slot + " | " + date;
    }
}
