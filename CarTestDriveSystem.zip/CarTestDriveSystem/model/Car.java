package model;

public class Car {

    private int id;
    private String name;
    private String brand;
    private double price;
    private boolean available;

    // Constructor
    public Car(int id, String name, String brand, double price, boolean available) {
        this.id = id;
        this.name = name;
        this.brand = brand;
        this.price = price;
        this.available = available;
    }

    // Convert object → file format
    public String toFileString() {
        return id + "," + name + "," + brand + "," + price + "," + available;
    }

    // Convert file → object
    public static Car fromFileString(String line) {
        String[] data = line.split(",");
        return new Car(
                Integer.parseInt(data[0]),
                data[1],
                data[2],
                Double.parseDouble(data[3]),
                Boolean.parseBoolean(data[4])
        );
    }

    // Getters & Setters
    public int getId() { return id; }

    public String getName() { return name; }

    public String getBrand() { return brand; }

    public double getPrice() { return price; }

    public boolean isAvailable() { return available; }

    public void setName(String name) { this.name = name; }

    public void setBrand(String brand) { this.brand = brand; }

    public void setPrice(double price) { this.price = price; }

    public void setAvailable(boolean available) { this.available = available; }

    @Override
    public String toString() {
        return id + " | " + name + " | " + brand + " | ₹" + price + " | " +
                (available ? "Available" : "Booked");
    }
}
