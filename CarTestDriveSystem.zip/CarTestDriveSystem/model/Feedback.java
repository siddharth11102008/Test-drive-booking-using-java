package model;

public class Feedback {

    private String customerName;
    private String message;
    private int rating;

    public Feedback(String customerName, String message, int rating) {
        this.customerName = customerName;
        this.message = message;
        this.rating = rating;
    }

    public String toFileString() {
        return customerName + "," + message + "," + rating;
    }

    public static Feedback fromFileString(String line) {
        String[] data = line.split(",");
        return new Feedback(
                data[0],
                data[1],
                Integer.parseInt(data[2])
        );
    }

    @Override
    public String toString() {
        return customerName + " | " + message + " | Rating: " + rating;
    }
}
