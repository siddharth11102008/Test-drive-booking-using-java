package service;

import model.Feedback;
import util.FileUtil;

import java.util.List;
import java.util.Scanner;

public class FeedbackService {

    private final String FILE_NAME = "data/feedback.txt";
    private Scanner sc = new Scanner(System.in);

    // ================= ADD FEEDBACK =================
    public void addFeedback() {
        try {
            System.out.print("Enter Your Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Feedback Message: ");
            String message = sc.nextLine();

            System.out.print("Enter Rating (1-5): ");
            int rating = sc.nextInt();
            sc.nextLine();

            if (rating < 1 || rating > 5) {
                System.out.println("Invalid Rating!");
                return;
            }

            Feedback feedback = new Feedback(name, message, rating);

            FileUtil.appendFile(FILE_NAME, feedback.toFileString());

            System.out.println("Feedback Submitted Successfully!");

        } catch (Exception e) {
            System.out.println("Invalid Input!");
            sc.nextLine();
        }
    }

    // ================= VIEW FEEDBACK =================
    public void viewFeedback() {
        List<String> data = FileUtil.readFile(FILE_NAME);

        if (data.isEmpty()) {
            System.out.println("No feedback available.");
            return;
        }

        System.out.println("\n--- CUSTOMER FEEDBACK ---");

        for (String line : data) {
            Feedback feedback = Feedback.fromFileString(line);
            System.out.println(feedback);
        }
    }
}
