package service;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import model.Booking;
import model.Car;
import util.FileUtil;

public class ReportService {

    private final String BOOKING_FILE = "data/bookings.txt";
    private final String CAR_FILE = "data/cars.txt";

    // ================= GENERATE REPORT =================
    public void generateReport() {

        List<String> bookingData = FileUtil.readFile(BOOKING_FILE);
        List<String> carData = FileUtil.readFile(CAR_FILE);

        System.out.println("\n===== REPORT =====");

        // ---------------- TOTAL BOOKINGS ----------------
        System.out.println("Total Bookings: " + bookingData.size());

        // ---------------- MOST BOOKED CAR ----------------
        Map<Integer, Integer> countMap = new HashMap<>();

        for (String line : bookingData) {
            Booking booking = Booking.fromFileString(line);
            int carId = booking.getCarId();

            countMap.put(carId, countMap.getOrDefault(carId, 0) + 1);
        }

        int maxCarId = -1;
        int maxCount = 0;

        for (Map.Entry<Integer, Integer> entry : countMap.entrySet()) {
            if (entry.getValue() > maxCount) {
                maxCount = entry.getValue();
                maxCarId = entry.getKey();
            }
        }

        if (maxCarId != -1) {
            for (String line : carData) {
                Car car = Car.fromFileString(line);
                if (car.getId() == maxCarId) {
                    System.out.println("Most Booked Car: " + car.getName() + " (" + maxCount + " bookings)");
                    break;
                }
            }
        } else {
            System.out.println("No bookings yet.");
        }

        // ---------------- AVAILABLE CARS ----------------
        System.out.println("\nAvailable Cars:");

        for (String line : carData) {
            Car car = Car.fromFileString(line);

            if (car.isAvailable()) {
                System.out.println(
                        car.getId() + " | "
                        + car.getName() + " | "
                        + car.getBrand() + " | "
                        + car.getPrice() + " | "
                        + "Available"
                );
            }
        }
    }
}