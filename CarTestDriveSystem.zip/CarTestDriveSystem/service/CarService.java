package service;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import model.Car;
import util.FileUtil;

public class CarService {

    private final String FILE_NAME = "data/cars.txt";
    private final Scanner sc = new Scanner(System.in);

    // ================= ADD CAR =================
    public void addCar() {
        try {
            System.out.print("Enter Car ID: ");
            int id = sc.nextInt();
            sc.nextLine();

            System.out.print("Enter Car Name: ");
            String name = sc.nextLine();

            System.out.print("Enter Brand: ");
            String brand = sc.nextLine();

            System.out.print("Enter Price: ");
            double price = sc.nextDouble();

            Car car = new Car(id, name, brand, price, true);

            FileUtil.appendFile(FILE_NAME, car.toFileString());
            System.out.println("Car Added Successfully!");

        } catch (Exception e) {
            System.out.println("Invalid Input!");
            sc.nextLine();
        }
    }

    // ================= VIEW CARS =================
    public void viewCars() {
        List<String> data = FileUtil.readFile(FILE_NAME);

        if (data.isEmpty()) {
            System.out.println("No cars available.");
            return;
        }

        System.out.println("\n--- CAR LIST ---");

        for (String line : data) {
            Car car = Car.fromFileString(line);

            System.out.println(
                    car.getId() + " | "
                    + car.getName() + " | "
                    + car.getBrand() + " | "
                    + car.getPrice() + " | "
                    + (car.isAvailable() ? "Available" : "Booked")
            );
        }
    }

    // ================= UPDATE CAR =================
    public void updateCar() {
        List<String> data = FileUtil.readFile(FILE_NAME);
        List<String> updated = new ArrayList<>();

        System.out.print("Enter Car ID to Update: ");
        int id = sc.nextInt();
        sc.nextLine();

        boolean found = false;

        for (String line : data) {
            Car car = Car.fromFileString(line);

            if (car.getId() == id) {
                found = true;

                System.out.print("Enter New Name: ");
                car.setName(sc.nextLine());

                System.out.print("Enter New Brand: ");
                car.setBrand(sc.nextLine());

                System.out.print("Enter New Price: ");
                car.setPrice(sc.nextDouble());
                sc.nextLine();

                updated.add(car.toFileString());
                System.out.println("Car Updated!");

            } else {
                updated.add(line);
            }
        }

        if (!found) {
            System.out.println("Car Not Found!");
        }

        FileUtil.writeFile(FILE_NAME, updated);
    }

    // ================= DELETE CAR =================
    public void deleteCar() {
        List<String> data = FileUtil.readFile(FILE_NAME);
        List<String> updated = new ArrayList<>();

        System.out.print("Enter Car ID to Delete: ");
        int id = sc.nextInt();

        boolean found = false;

        for (String line : data) {
            Car car = Car.fromFileString(line);

            if (car.getId() == id) {
                found = true;
                System.out.println("Car Deleted!");
            } else {
                updated.add(line);
            }
        }

        if (!found) {
            System.out.println("Car Not Found!");
        }

        FileUtil.writeFile(FILE_NAME, updated);
    }
}