
package service;

import model.*;
import util.FileUtil;

import java.util.*;

public class BookingService {

    Scanner sc = new Scanner(System.in);

    String BOOK = "data/bookings.txt";
    String CAR = "data/cars.txt";

    String[] slots = {"10-11","11-12","1-2","2-3","4-5"};

    public void bookTestDrive() {

        for(String l: FileUtil.readFile(CAR)){
            Car c = Car.fromFileString(l);
            if(c.isAvailable()) System.out.println(c);
        }

        System.out.print("Name: "); sc.nextLine();
        String name = sc.nextLine();

        System.out.print("Car ID: ");
        int carId = sc.nextInt();

        for(int i=0;i<slots.length;i++)
            System.out.println((i+1)+"."+slots[i]);

        int s = sc.nextInt();
        String slot = slots[s-1];

        System.out.print("Date: "); sc.nextLine();
        String date = sc.nextLine();

        if(isSlotBooked(carId,slot,date)){
            System.out.println("Slot already booked!");
            return;
        }

        int id = FileUtil.readFile(BOOK).size()+1;

        Booking b = new Booking(id,name,carId,slot,date);
        FileUtil.appendFile(BOOK,b.toFileString());

        System.out.println("Booked!");
    }

    private boolean isSlotBooked(int cid,String slot,String date){
        for(String l: FileUtil.readFile(BOOK)){
            Booking b = Booking.fromFileString(l);
            if(b.getCarId()==cid && b.getSlot().equals(slot) && b.getDate().equals(date))
                return true;
        }
        return false;
    }

    public void viewBookings(){
        for(String l: FileUtil.readFile(BOOK))
            System.out.println(Booking.fromFileString(l));
    }
}
