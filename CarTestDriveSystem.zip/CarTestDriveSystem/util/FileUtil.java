package util;

import java.io.*;
import java.util.ArrayList;
import java.util.List;

public class FileUtil {

    // ================= READ FILE =================
    public static List<String> readFile(String fileName) {
        List<String> list = new ArrayList<>();

        try {
            File file = new File(fileName);

            // Create file if not exists
            if (!file.exists()) {
                file.createNewFile();
            }

            BufferedReader br = new BufferedReader(new FileReader(file));
            String line;

            while ((line = br.readLine()) != null) {
                if (!line.trim().isEmpty()) {
                    list.add(line);
                }
            }

            br.close();

        } catch (Exception e) {
            System.out.println("Error reading file: " + e.getMessage());
        }

        return list;
    }

    // ================= WRITE FILE (Overwrite) =================
    public static void writeFile(String fileName, List<String> data) {

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileName));

            for (String line : data) {
                bw.write(line);
                bw.newLine();
            }

            bw.close();

        } catch (Exception e) {
            System.out.println("Error writing file: " + e.getMessage());
        }
    }

    // ================= APPEND FILE =================
    public static void appendFile(String fileName, String data) {

        try {
            BufferedWriter bw = new BufferedWriter(new FileWriter(fileName, true));
            bw.write(data);
            bw.newLine();
            bw.close();

        } catch (Exception e) {
            System.out.println("Error appending file: " + e.getMessage());
        }
    }
}
